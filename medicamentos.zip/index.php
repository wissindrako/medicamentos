<?php
header('Location: public');
?>