<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class ControlMaleza extends Model
{
    protected $table = 'enc_controles_maleza';
}
