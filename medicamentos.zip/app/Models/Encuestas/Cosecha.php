<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class Cosecha extends Model
{
    protected $table = 'enc_cosechas';
}
