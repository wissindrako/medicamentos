<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class Densidad extends Model
{
    protected $table = 'enc_densidad';

    protected $guraded = ['id_densidad'];
}
