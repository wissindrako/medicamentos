<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class InformacionBasica extends Model
{
    protected $table = 'enc_productores';
}
