<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class PostCosecha extends Model
{
    protected $table = 'enc_post_cosechas';
}
