<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class Plaga extends Model
{
    protected $table = 'enc_plagas';
}
