<?php

namespace App\Models\Encuestas;

use Illuminate\Database\Eloquent\Model;

class Agroforestal extends Model
{
    protected $table = 'enc_sist_agroforestales';
}
