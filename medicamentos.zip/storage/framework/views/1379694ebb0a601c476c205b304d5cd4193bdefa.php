<div class="col-md-12">
    <div class="form-group">
        <label >Nombre</label>
        <input type="input" name="nombre" placeholder="" class="form-control" value="<?php echo e(old('nombre')); ?>"/>
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label >Apellido Paterno</label>
        <input type="input" name="paterno" placeholder="" class="form-control" value="<?php echo e(old('paterno')); ?>" />
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label >Apellido Materno</label>
        <input type="input" name="materno" placeholder="" class="form-control" value="<?php echo e(old('materno')); ?>" />
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label >Carnet</label>
        <input type="input" name="cedula_identidad" id="input_cedula" placeholder="" class="form-control" value="<?php echo e(old('cedula_identidad')); ?>" pattern="[0-9]{6,9}"/>
    </div>
</div>

<div class="col-md-12">
    <div class="form-group">
        <label >Celular</label>
        <input type="input" name="telefono_celular" placeholder="" class="form-control" value="<?php echo e(old('telefono_celular')); ?>" pattern="[0-9]{6,9}"/>
    </div>
</div>
<div class="col-md-12">
    <div class="form-group">
        <label class="text-black">Rol</label>
        <div class="form-group bg-gray">
            <select  class="form-control" name="rol" id="rol_slug">
              <?php if(!old('rol')): ?>
                <option value="" selected> --- SELECCIONE UN ROL --- </option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <option value=<?php echo e($rol->id); ?>><?php echo e($rol->description); ?></option>                                                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php else: ?>
                <option value=""> --- SELECCIONE UN ROL --- </option>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <option value="<?php echo e($rol->id); ?>" <?php echo e(old('rol', $rol->id) == $rol->id ? 'selected' : ''); ?>><?php echo e($rol->description); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
              <?php endif; ?>
            </select>
        </div>
    </div>
</div>
<div class="col-md-6" id="div_edad">
    <div class="form-group">
        <label class=" ">Edad</label>
        <?php if(Auth::guest()): ?>
            <input style='line-height: initial;' type="number" name="edad" id="edad" placeholder="" min="18" max="110" class="form-control" value="<?php echo e(old('edad')); ?>" required/>
        <?php else: ?>
            <?php if (\Shinobi::isRole('paciente')): ?>
            <input style='line-height: initial;' type="number" name="edad" id="edad" placeholder="" min="60" max="110" class="form-control" value="<?php echo e(old('edad')); ?>" required/>
            <?php endif; ?>
            <?php if (\Shinobi::isRole('medico')): ?>
            <input style='line-height: initial;' type="number" name="edad" id="edad" placeholder="" min="20" max="110" class="form-control" value="<?php echo e(old('edad')); ?>" required/>
            <?php endif; ?>
            <?php if (\Shinobi::isRole('super_admin')): ?>
            <input style='line-height: initial;' type="number" name="edad" id="edad" placeholder="" min="20" max="110" class="form-control" value="<?php echo e(old('edad')); ?>" required/>
            <?php endif; ?>
        <?php endif; ?>
       
    </div>
</div>
<div class="col-md-6" id="div_sexo">
    <div class="form-group">
        <label class="text-black">Sexo</label>
        <div class="form-group bg-gray">
          <select class="form-control" name="sexo" id="sexo" required>
            <?php if(!old('sexo')): ?>
              <option value="" selected> --- SELECCIONE SU GENERO --- </option>
              <option value="MASCULINO">MASCULINO</option>
              <option value="FEMENINO">FEMENINO</option>
            <?php else: ?>
              <option value=""> --- SELECCIONE SU GENERO --- </option>
              <option value="MASCULINO" <?php echo e(old('sexo') == 'MASCULINO' ? 'selected' : ''); ?>>MASCULINO</option>
              <option value="FEMENINO" <?php echo e(old('sexo') == 'FEMENINO' ? 'selected' : ''); ?>>FEMENINO</option>
            <?php endif; ?>
          </select>
        </div>
    </div>
</div>


<div class="col-md-12" id="div_institucion">
    <div class="form-group">
        <label >Institucion</label>
        <input type="input" name="institucion" id="institucion" placeholder="" class="form-control" value="<?php echo e(old('institucion')); ?>"/>
    </div>
</div>
<div class="col-md-12" id="div_especialidad">
    <div class="form-group">
        <label >Especialidad</label>
        <input type="input" name="especialidad" id="especialidad" placeholder="" class="form-control" value="<?php echo e(old('especialidad')); ?>"/>
    </div>
</div>

<div class="col-md-12" id="div_medico">
    <div class="form-group">
        <label class="text-black">Médico de Cabecera</label>
        <div class="form-group bg-gray">
          <select  class="form-control" name="medico" id="medico">

            <?php if(!old('medico')): ?>
                <option value="" selected> --- SELECCIONE UN MEDICO --- </option>
                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php if($item->usuario->roles[0]->slug == 'medico'): ?>
                        <option value=<?php echo e($item->id_persona); ?>><?php echo e($item->nombre); ?> <?php echo e($item->paterno); ?> <?php echo e($item->materno); ?></option>                                                
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php else: ?>
                <option value=""> --- SELECCIONE UN MEDICO --- </option>
                <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <?php if($item->usuario->roles[0]->slug == 'medico'): ?>
                    <option value="<?php echo e($item->id_persona); ?>" <?php echo e(old('medico', $item->id_persona) == $item->id_persona ? 'selected' : ''); ?>><?php echo e($item->nombre); ?> <?php echo e($item->paterno); ?> <?php echo e($item->materno); ?></option>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            <?php endif; ?>
        </select>
        </div>
    </div>
</div>




<div class="col-md-12">
    <br>
</div>