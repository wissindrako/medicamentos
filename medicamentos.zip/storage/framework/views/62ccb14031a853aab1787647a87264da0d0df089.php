 
  
<?php $__env->startSection('content'); ?>

  <body class="mybody">      
    <div class="mytop-content" >
        <div class="container" > 
          
                <div class="col-sm-12" style="background-color:#296dc0; height: 60px;">
                   

                  <a class="mybtn-social pull-right" href="<?php echo e(url('/login')); ?>">
                       Login
                  </a>
               
                </div>
            
                <div class="row">
                  <div class="col-sm-6 col-sm-offset-3 myform-cont" >
                        <div class="myform-top-login">
                          <br>
                          <img  src="<?php echo e(url('img/avatar.png')); ?> " class="img-responsive myform-img-top-center"/>

                  <div class="col-md-12" >
                    <?php if(count($errors) > 0): ?>
                     
                        <div class="alert alert-danger">
                            <strong>UPPS!</strong> Error al Registrar<br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                    
                    <?php endif; ?>
                   </div  >

                    <div class="myform-bottom-login">
                      
                        <form action="<?php echo e(url('agregar_persona')); ?>"  method="post" id="f_enviar_agregar_persona" class="" enctype="multipart/form-data">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">

                            <?php echo $__env->make('formularios.persona.form_agregar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                        <button type="submit" class="mybtn">Registrarme</button>
                      </form>
                    
                    </div>
              </div>
            </div>
            
        </div>
      </div>
 
 </body>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <?php echo $__env->make('layouts.partials.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('formularios.persona.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>