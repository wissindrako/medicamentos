<?php $__env->startSection('htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>

<section  id="contenido_principal">

<div class="box box-primary box-white">
     <div class="box-header">
        <h4 class="box-title">Usuarios</h4>	        


    </div>

<div class="box-body box-white">

    <div class="table-responsive" >

	    <table  class="table table-hover table-striped" cellspacing="0" width="100%">
			<thead>
				<tr>    
					<th>codigo</th>
					<th>Rol</th>
					<th>Nombre</th>
					<th>Carnet</th>
					<th>Usuario</th>
					<th>Pass</th>
					<th>Acción</th>
				</tr>
			</thead>
	    <tbody>

	    <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr role="row" class="odd">
			<td><?php echo e($usuario->id); ?></td>
			<td><span class="label label-default">
             
             <?php $__currentLoopData = $usuario->getRoles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roles): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
			 <?php echo e($roles.","); ?>

             <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
           
             -</span>
			</td>
			<td class="mailbox-messages mailbox-name"><a href="javascript:void(0);"  style="display:block"><i class="fa fa-user"></i>&nbsp;&nbsp;<?php echo e($usuario->persona['nombre']); ?> <?php echo e($usuario->persona['paterno']); ?> <?php echo e($usuario->persona['materno']); ?></a></td>
			<td class="mailbox-messages mailbox-name"><a href="javascript:void(0);"  style="display:block"><i class="fa fa-credit-card"></i>&nbsp;&nbsp;<?php echo e($usuario->persona['cedula_identidad']); ?></a></td>
			<td><?php echo e($usuario->name); ?></td>
			<td><?php echo e($usuario->email); ?></td>
			<td>
			<button type="button" class="btn  btn-default btn-xs" onclick="verinfo_usuario(<?php echo e($usuario->id); ?>, 1)" ><i class="fa fa-fw fa-edit"></i></button>
			
			</td>
		</tr>
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>



		</tbody>
		</table>

	</div>
</div>




<?php echo e($usuarios->links()); ?>


<?php if(count($usuarios)==0): ?>


<div class="box box-primary col-xs-12">

<div class='aprobado' style="margin-top:70px; text-align: center">
 
<label style='color:#177F6B'>
              ... no se encontraron resultados para su busqueda...
</label> 

</div>

 </div> 


<?php endif; ?>

</div></section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>