<?php $__env->startSection('htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
	<div class="container spark-screen">
		<div class="row">
			

			<div style="text-align:center">

				<h1 class=""><b>SISTEMA EXPERTO </b></h1>
				
				<img src="<?php echo e(asset('img/logo-univalle.jpeg')); ?>" style="width:550x;height:450px;" class="centered"/>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>