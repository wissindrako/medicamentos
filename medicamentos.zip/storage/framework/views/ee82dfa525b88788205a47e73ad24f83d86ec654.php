<?php $__env->startSection('htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<section  id="contenido_principal">

<div class="box box-primary">
		<div class="box-header">
				<h3 class="box-title">Listado de Personas</h3>
				<input type="hidden" id="rol_usuario" value="">
				<?php if (\Shinobi::isRole('super_admin')): ?>
				<div class="box-tools">
                    <a href="<?php echo e(route('form_agregar_persona')); ?>" class="btn btn-sm">
                        <i class="fa fa-fw fa-plus-circle"></i> Nuevo Registro
                    </a>
				</div>
				<?php endif; ?>
			
		</div>
		<!-- /.box-header -->
		
		<div class="box-body table-responsive no-padding">
		  <table id="tabla_personas" class="table table-striped table-hover hoverTableww">
			<thead>
				<th>Nombre</th>
				<?php if (\Shinobi::isRole('super_admin')): ?>
				<th>Carnet</th>
				<?php endif; ?>
				<th>Celular</th>
				<th>Edad</th>
				<th>Sexo</th>
				<?php if (\Shinobi::isRole('super_admin')): ?>
				<th>Rol</th>
				<?php endif; ?>
				<th>Opciones</th>
				
			</thead>
			<tbody>
				<?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				
					<tr class='clickable-roww' data-href="<?php echo e(route('opciones_persona', ['id' => $item->id_persona])); ?>">
						<td><?php echo e($item->nombre); ?> 
							<?php if (\Shinobi::isRole('medico')): ?>
								<?php if($item->paterno): ?>
								<?php echo e($item->paterno); ?>

								<?php else: ?>
								<?php echo e($item->materno ?? ''); ?>

								<?php endif; ?>
							<?php endif; ?>
							<?php if (\Shinobi::isRole('super_admin')): ?>
							<?php echo e($item->paterno); ?> <?php echo e($item->materno); ?>

							<?php endif; ?>
						</td>	
						<?php if (\Shinobi::isRole('super_admin')): ?>
						<td><?php echo e($item->cedula_identidad); ?></td>
						<?php endif; ?>
						<td><?php echo e($item->telefono_celular); ?></td>
						<td><?php echo e($item->edad); ?></td>
						<td>
							<?php if($item->sexo = 'MASCULINO'): ?>
							M
							<?php else: ?>
							F
							<?php endif; ?>
						</td>
						<?php if (\Shinobi::isRole('super_admin')): ?>
						<td><?php echo e($item->usuario->roles[0]->description ?? ''); ?></td>
						<?php endif; ?>
						<td>
							<a href="<?php echo e(route('opciones_persona', ['id' => $item->id_persona])); ?>" class="btn btn-primary btn-sm">
								<i class="fa fa-edit"></i>
							</a>
							<?php if($item->usuario->roles[0]->slug == 'paciente'): ?>
							<?php if (\Shinobi::isRole('super_admin')): ?>
							<button type="button"  class="btn btn-danger btn-sm"  onclick="eliminar_paciente_medico(<?php echo e($item->id_persona); ?>);"  ><i class="fa fa-fw fa-remove"></i></button>
							<?php endif; ?>
							<?php if (\Shinobi::isRole('medico')): ?>
							<button type="button"  class="btn btn-danger btn-sm"  onclick="borrado_paciente(<?php echo e($item->id_persona); ?>);"  ><i class="fa fa-fw fa-remove"></i></button>
							<?php endif; ?>
							<?php if (\Shinobi::isRole('paciente')): ?>
							<button type="button" class="btn btn-danger btn-sm" disabled><i class="fa fa-fw fa-remove"></i></button>
							<?php endif; ?>
							<?php endif; ?>
							<?php if($item->usuario->roles[0]->slug == 'medico'): ?>
							<?php if (\Shinobi::isRole('super_admin')): ?>
							<button type="button"  class="btn btn-danger btn-sm"  onclick="eliminar_paciente_medico(<?php echo e($item->id_persona); ?>);"  ><i class="fa fa-fw fa-remove"></i></button>
							<?php endif; ?>
							<?php endif; ?>
							<?php if($item->usuario->roles[0]->slug == 'super_admin'): ?>
							<?php if (\Shinobi::isRole('super_admin')): ?>
							<button type="button"  class="btn btn-danger btn-sm" disabled><i class="fa fa-fw fa-remove"></i></button>
							<?php endif; ?>
							<?php endif; ?>
							
						</td>
					</tr>
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>

		</table>
			<?php if(count($personas) == 0): ?>
			<div class="box box-primary col-xs-12">
				<div class='aprobado' style="margin-top:70px; text-align: center">
				<label style='color:#177F6B'>
					... no se encontraron resultados para su busqueda...
				</label>
				</div>
			</div>
			<?php endif; ?>
		</div>
		<!-- /.box-body -->
	  </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

@parent

<script>

	$(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>