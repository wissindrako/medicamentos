<div class="col-md-12">

    <div class="box box-primary col-md-12 box-gris">
 
        <div class="box-header with-border my-box-header">
        <h3 class="box-title"><strong>Nuevo permiso</strong></h3>
        </div><!-- /.box-header -->
        <hr style="border-color:white;" />
        <div class="box-body">

                <div class="col-md-6">
		             <form   action="<?php echo e(url('asignar_permiso')); ?>"  method="post" id="f_asignar_permiso" class="formentrada"  >
						<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>"> 
						<div class="form-group">
							<label class="col-sm-2" for="rol">Rol*</label>
		    			<div class="col-sm-10" >
								<select id="rol_sel" name="rol_sel" class="form-control" required>
									<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
									<option value="<?php echo e($rol->id); ?>"><?php echo e($rol->name); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		    				</select>
              </div>
						</div><!-- /.form-group -->

						<div class="form-group">
							<label class="col-sm-2" for="rol">Permisos*</label>
		    			<div class="col-sm-10" >
		                     
		                     <select id="permiso_rol" name="permiso_rol" class="form-control" required>
		                     <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		                     <option value="<?php echo e($permiso->id); ?>"><?php echo e($permiso->name); ?></option>
		                     <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		    				</select>
		                     
		                </div>
						</div><!-- /.form-group -->

						<div class="box-footer col-xs-12 box-gris ">
		                        <button type="submit" class="btn btn-primary">Agregar Permiso</button>
		                </div>
					 </form>
		        </div>

			


			    <div class="col-md-6">
              
		            <form   action="<?php echo e(url('crear_permiso')); ?>"  method="post" id="f_crear_permiso" class="formentrada"  >
						<input type="hidden" name="_token" value="<?php echo csrf_token(); ?>"> 
		                


		                
		                <div class="col-md-12">	  
			                <div class="form-group">
									<label class="col-sm-2" for="apellido">Permiso*</label>
			                    <div class="col-sm-10" >
									<input type="text" class="form-control" id="permiso_nombre" name="permiso_nombre" " required >
			                    </div>
							</div><!-- /.form-group -->

					    </div><!-- /.col -->

					      <div class="col-md-12">	  
			                <div class="form-group">
									<label class="col-sm-2" for="apellido">Slug*</label>
			                    <div class="col-sm-10" >
									<input type="text" class="form-control" id="permiso_slug" name="permiso_slug" " required >
			                    </div>
							</div><!-- /.form-group -->

					    </div><!-- /.col -->

					      <div class="col-md-12">	  
			                <div class="form-group">
									<label class="col-sm-2" for="apellido">Descripcion*</label>
			                    <div class="col-sm-10" >
									<input type="text" class="form-control" id="permiso_descripcion" name="permiso_descripcion" " required >
			                    </div>
							</div><!-- /.form-group -->

					    </div><!-- /.col -->


		                <div class="box-footer col-xs-12 box-gris ">
		                        <button type="submit" class="btn btn-primary">Crear Nuevo Permiso</button>
		                </div>
		            </form>
                </div>          
        </div>
                    
    </div>
                       
</div>


<div class="col-md-12 box-white">

<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

    <div class="table-responsive" >

	    <table  class="table table-hover table-striped" cellspacing="0" width="100%">
				
                <thead>
                <th colspan="5" style="text-align: center; background-color: #b8ccde;" >Permisos del Usuario <?php echo e($rol->name); ?></th>
                </thead>
				<thead>
						    <th>codigo</th>
								<th>nombre</th>
								<th>slug</th>
								<th>descripcion</th>
							    <th>Acción</th>
						
				</thead>
	    <tbody>
	 

	    <?php $__currentLoopData = $rol->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		   
        
		 <tr role="row" class="odd" id="filaP_<?php echo e($permiso->id); ?>">
			<td><?php echo e($permiso->id); ?></td>
			<td><span class="label label-default"><?php echo e(isset($permiso->name) ? $permiso->name : "Ninguno"); ?></span></td>
			<td class="mailbox-messages mailbox-name"><a href="javascript:void(0);" style="display:block"></i>&nbsp;&nbsp;<?php echo e($permiso->slug); ?></a></td>
			<td><?php echo e($permiso->description); ?></td>
			<td>
			<button type="button"  class="btn  btn-danger btn-xs"  onclick="borrar_permiso(<?php echo e($rol->id); ?>,<?php echo e($permiso->id); ?>);"  ><i class="fa fa-fw fa-remove"></i></button>
			</td>
		   </tr>
	
	    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</tbody>
		</table>

	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

</div>



