<?php $__env->startSection('htmlheader_title'); ?>
	Oociones Paciente
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<section  id="contenido_principal">
<section  id="content">

    <div class="" >
        <div class="container">
            <div class="row">
                <?php if($persona[0]->usuario->roles[0]->slug == 'paciente'): ?>
                <?php echo $__env->make('formularios.sistema_experto.datos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="col-md-7" >
                <?php else: ?>
                <div class="col-sm-8 col-sm-offset-2 myform-cont" >
                <?php endif; ?>

									<?php if(session()->has('mensaje_exito')): ?>
										<div class="alert alert-success">
										<?php echo e(session()->get('mensaje_exito')); ?>

										</div>
									<?php endif; ?>
									<?php if(session()->has('mensaje_error')): ?>
										<div class="alert alert-warning">
										<?php echo e(session()->get('mensaje_error')); ?>

										</div>
									<?php endif; ?>

                 <div class="myform-top">
                    <div class="myform-top-left">
                      <h3>Opciones</h3>
                    </div>
                    <div class="myform-top-right">
                        <?php if (\Shinobi::isRole('super_admin')): ?>
                        <a href="<?php echo e(route('listado_personas')); ?>" class="">
                            <i class="fa fa-th" style="color:white"></i>
                          </a>
                        <?php endif; ?>
                        <?php if (\Shinobi::isRole('medico')): ?>
                        <a href="<?php echo e(route('listado_personas')); ?>" class="">
                            <i class="fa fa-th" style="color:white"></i>
                          </a>
                        <?php endif; ?>
                        <?php if (\Shinobi::isRole('paciente')): ?>
                        <i class="fa fa-edit"></i>
                        <?php endif; ?>

                    </div>
                  </div>

                  <div class="col-md-12" >
                    <?php if(count($errors) > 0): ?>

                        <div class="alert alert-danger">
                            <strong>UPPS!</strong> Error al Registrar<br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>

                    <?php endif; ?>
                </div  >

                <div class="row">
                    <div class="col-md-12">
                        <div class="myform-bottom">
                            
                            <?php if($persona[0]->usuario->roles[0]->slug == 'super_admin' || $persona[0]->usuario->roles[0]->slug == 'medico'): ?>
                            <hr>
                            <div class="row">
                                    <i class="fa fa-book margin-r-5"></i><b><?php echo e($persona[0]->usuario->roles[0]->description); ?>: </b>
                                    <?php echo e($persona[0]->nombre); ?> <?php echo e($persona[0]->paterno); ?> <?php echo e($persona[0]->materno); ?>

                                    <?php if (\Shinobi::isRole('super_admin')): ?>
                                    <hr>
                                    <div class="box box-solid">
                                        <div class="box-header bg-primary">
                                            <h3 class="box-title">Pacientes</h3>
                                        </div>
                                        <table class="table table-striped table-hover">
                                            <thead>
                                                <th>Nombre</th>
                                                <th>Celular</th>
                                            </thead>
                                            <tbody>
                                                <?php $__empty_1 = true; $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        <td><?php echo e($item->nombre); ?> <?php echo e($item->paterno); ?> <?php echo e($item->materno); ?></td>
                                                        <td><?php echo e($item->telefono_celular); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                                                    <tr><td colspan="2">No hay Pacientes asignados</td></tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <hr>
                            <div class="row">

                                <?php echo $__env->make('formularios.opciones.datos_personales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                                <?php if($persona[0]->usuario->roles[0]->slug == 'paciente'): ?>
                                    <?php echo $__env->make('formularios.opciones.historial', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                <?php endif; ?>

                            &nbsp;&nbsp;&nbsp;
                            

                        </div>
                    </div>
                </div>

              </div>
            </div>

        </div>
      </div>

</section>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>