<?php $__env->startSection('htmlheader_title'); ?>
	Diagnóstico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section  id="contenido_principal">
<section  id="content">

    <div class="" >
        <div class="container"> 
            <div class="row">

                <!-- /.col -->

                <div class="col-md-12">
                  <!-- Box Comment -->
                  <div class="box box-widget">
                    <div class="box-header with-border">
                      <h3>Sistema Experto</h3>
                      
                      <!-- /.user-block -->
                      <div class="box-tools">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                        </button>
                      </div>
                      <!-- /.box-tools -->
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body" style="">
                      <img class="img-responsive pad" src="<?php echo e(url('img/arbol.png')); ?>" alt="Arbol">
        
                      
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer box-comments" style="">

                      <!-- /.box-comment -->
                      <div class="box-comment">
                        <!-- User image -->

                      <!-- /.box-comment -->
                    </div>
                    <!-- /.box-footer -->
                    <div class="box-footer" style="">

                    </div>
                    <!-- /.box-footer -->
                  </div>
                  <!-- /.box -->
                </div>
                <!-- /.col -->
              </div>

        </div>
      </div>
 
</section>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
@parent



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>