<?php $__env->startSection('content'); ?>

<body class="mybody">
    <div class="mytop-content" >
        <div class="container" >

            <div class="col-sm-12" style="background-color:#296dc0; height: 60px;">
              

              <a class="mybtn-social pull-right" href="<?php echo e(url('/register')); ?>">
                  Registro
              </a>

            </div>

            <div class="row">
              <div class="col-sm-6 col-sm-offset-3 myform-cont" >
                    <div class="myform-top-login">
                      <br>
                      <img  src="<?php echo e(url('img/avatar.png')); ?> " class="img-responsive myform-img-top-center"/>

                    </div>

            <?php if(count($errors) > 0): ?>
                 <div class="col-sm-12" >
                        <div class="alert alert-danger">
                            <strong>Whoops!</strong> Error de Accesso
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                </div>
                <?php endif; ?>
                    <div class="myform-bottom-login">
                      <br>
                      <form role="form" action="<?php echo e(url('/login')); ?>" method="post" >
                       <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="form-group">
                            <input type="text" name="email" value="<?php echo e(old('email')); ?>" placeholder="Nombre" class="form-control" id="form-username">
                        </div>
                        <div class="form-group">
                            <input type="password" name="password" placeholder="Clave" class="form-control" id="form-password">
                        </div>

                        

                        <button type="submit" class="mybtn">Ingresar</button>
                      </form>

                    </div>
              </div>
            </div>
        </div>
      </div>

    <!-- Enlazamos el js de Bootstrap, y otros plugins que usemos siempre al final antes de cerrar el body -->
    <script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
  </body>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>