<div class="col-md-3">
    
    <div class="box box-solid">
      <div class="box-header with-border bg-navy">
        <h3 class="box-title"><b>Datos Personales</b></h3>
        <div class="box-tools">
          <button type="button" class="btn btn-box-tool" id="minimizar" data-widget="collapse"><i class="fa fa-plus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <b><i class="fa fa-pencil margin-r-5"></i> <?php echo e($persona[0]->usuario->roles[0]->description); ?>:</b>

        <p class="text-muted">

          <?php echo e($paciente->nombre); ?> <?php echo e($paciente->paterno); ?> <?php echo e($paciente->materno); ?>


        </p>

        <b><i class="fa fa-pencil margin-r-5"></i> Celular:</b>

        <p class="text-muted"><?php echo e($paciente->telefono_celular); ?></p>

        <b><i class="fa fa-pencil margin-r-5"></i> Edad:</b>

        <p class="text-muted"><?php echo e($paciente->edad); ?></p>

        <b><i class="fa fa-pencil margin-r-5"></i> Sexo:</b>

        <p class="text-muted"><?php echo e($paciente->sexo); ?></p>

      </div>
      <!-- /.box-body -->
    </div>
    <div class="box box-solid collapsed-box">
      <div class="box-header with-border bg-navy">
        <h3 class="box-title"><b>Médico de Cabecera</b></h3>
        <div class="box-tools">
          <button type="button" class="btn btn-box-tool" id="minimizar" data-widget="collapse"><i class="fa fa-plus"></i>
          </button>
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body">
        <b><i class="fa fa-user-md margin-r-5"></i> Médico:</b>

        <p class="text-muted">
          <?php if(isset($medico)): ?>
          <?php echo e($medico->nombre); ?> <?php echo e($medico->paterno); ?> <?php echo e($medico->materno); ?>

          <?php else: ?>
          No asignado aún!
          <?php endif; ?>
        </p>

      </div>
      <!-- /.box-body -->
    </div>

    <div class="box box-solid collapsed-box">
      <div class="box-header with-border bg-navy">
        <h3 class="box-title"><b>Historia Clínica</b></h3>
        <div class="box-tools">
          <button type="button" class="btn btn-box-tool" id="minimizar" data-widget="collapse"><i class="fa fa-plus"></i>
          </button>
        </div>
      </div>
      <div class="box-body">
          <b><i class="fa fa-circle-o margin-r-5"></i> Antecedentes:</b>

          <p class="text-muted">
            
            <?php $__empty_1 = true; $__currentLoopData = $antecedentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
              <?php echo e($item); ?><?php echo e($value ? ' : '.$value.', ' : ', '); ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                No hay antecedentes registrados
            <?php endif; ?>

          </p>

          

          <b><i class="fa fa-circle-o margin-r-5"></i> Falencias</b>
          <p class="text-muted">

            <?php $__empty_1 = true; $__currentLoopData = $enfermedades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item => $value): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
              <?php echo e($item); ?><?php echo e($value ? ' : '.$value.', ' : ', '); ?>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <p>No hay enfermedades registradas</p>
            <?php endif; ?>
          </p>
          

          <b><i class="fa fa-circle-o margin-r-5"></i> Alergias</b>
          <p class="text-muted">
            <?php $__empty_1 = true; $__currentLoopData = $alergias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>               
              <?php if($loop->last): ?>
              <?php echo e($item); ?>

              <?php else: ?>
              <?php echo e($item); ?>, 
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <p>No hay alergias registradas</p>
            <?php endif; ?>
          </p>

          <b><i class="fa fa-circle-o margin-r-5"></i> Consumo de medicamentos</b>
          <p class="text-muted">
            <?php $__empty_1 = true; $__currentLoopData = $recetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
              <?php if($loop->last): ?>
              <?php echo e($item); ?>

              <?php else: ?>
              <?php echo e($item); ?>, 
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <p>No consume ningún medicamento</p>
            <?php endif; ?>
          </p>

          <b><i class="fa fa-circle-o margin-r-5"></i> Familiares</b>

          
            <?php $__empty_1 = true; $__currentLoopData = $familiares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
              <p class="text-muted">
                <?php echo e($item->parentesco); ?>: <?php echo e($item->nombre); ?> <?php echo e($item->paterno); ?> <?php echo e($item->materno); ?> 
                Cel.: <?php echo e($item->telefono_celular); ?>

              </p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <p>No tiene familiares registrados.</p>
            <?php endif; ?>
          
  
        </div>
      <!-- /.box-body -->
    </div>
    <?php if (\Shinobi::isRole('super_admin')): ?>
    
    <div class="box box-solid">
      <div class="box-body">
        <a href="<?php echo e(url('arbol')); ?>" class="btn btn-primary btn-block"><b>Arbol SE</b></a>
      </div>
      <!-- /.box-body -->
    </div>
    <?php endif; ?>
  </div>