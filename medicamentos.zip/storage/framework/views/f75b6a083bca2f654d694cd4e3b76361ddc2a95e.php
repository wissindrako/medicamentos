<a href="<?php echo e(route('form_editar_persona', ['id' => $persona[0]->id_persona])); ?>" class="small-box-footer">
    <?php if($persona[0]->usuario->roles[0]->slug == 'medico' || $persona[0]->usuario->roles[0]->slug == 'super_admin'): ?>
    <div class="col-md-12 col-lg-12 col-xs-12">
    <?php else: ?>
    <div class="col-md-12 col-lg-6 col-xs-12">
    <?php endif; ?>
        <!-- small box -->
        <div class="small-box bg-primary">
        <div class="inner">
            <h2><b>Datos Personales</b></h2>
            <br>
            
        </div>
        <div class="icon">
            <i class="fa fa-user"></i>
        </div>
        <br>
        
        </div>
    </div>
</a>