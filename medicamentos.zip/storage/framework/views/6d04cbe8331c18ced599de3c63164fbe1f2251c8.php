<?php $__env->startSection('htmlheader_title'); ?>
	Diagnóstico
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section  id="contenido_principal">
<section  id="content">

    <div class="" >
        <div class="container"> 
            <div class="row">
                <?php echo $__env->make('formularios.sistema_experto.datos', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <!-- /.col -->

                <div class="col-md-9">
                  <div class="box box-primary">
                    <div class="box-header with-border">
                      <h3 class="box-title"><b>Sistema Experto</b></h3>
                      <hr>
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label for="">Medicamento</label>
                              
                              <select class="form-control input-lg select2" id="dato" style="width: 100%;">
                                <option selected="selected" disabled>Buscar</option>
                                <?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <option><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                              </select>
                            </div>
                            <!-- /.form-group -->
                            <div class="form-group">
                              <br>
                              <button onclick="consultar()" class="btn btn-primary pull-right btn-block btn-lg">Consultar</button>
                            </div>
                            <!-- /.form-group -->
                          </div>
                        </div>

                      <!-- /.box-tools -->
                    </div>
                    <div class="box-body" id="div_diagnostico">
                      <div class="box-header">
                          <h3 class="box-title"><b>Resultados</b></h3>
                      </div>
                      <div class="box-body table-responsive no-padding scrollable">
                          <table class="table table-bordered table-hover" id="tabla_diagnostico">
                              <thead>
                              <tr>
                                  <th>Premisa</th>
                                  <th>Resultado</th>
                                  <th>Conclusión</th>
                                  <th></th>
                              </tr>
                              </thead>
                              <tbody>
                              </tbody>
                          </table>
                      </div>
                    </div>

                  </div>
                  <!-- /. box -->
                </div>
                <!-- /.col -->
              </div>

        </div>
      </div>
 
</section>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
@parent

<?php echo $__env->make('formularios.sistema_experto.scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>