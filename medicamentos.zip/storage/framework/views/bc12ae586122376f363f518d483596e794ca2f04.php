<?php $__env->startSection('htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>


<?php $__env->startSection('main-content'); ?>
<section  id="contenido_principal">

<div class="box box-primary">
		<div class="box-header">
				<h3 class="box-title">Listado de Medicamentos</h3>
				<input type="hidden" id="rol_usuario" value="">
				<?php if (\Shinobi::isRole('super_admin')): ?>
				<div class="box-tools">
                    <a href="<?php echo e(route('form_agregar_medicamento')); ?>" class="btn btn-sm">
                        <i class="fa fa-fw fa-plus-circle"></i> Nuevo Registro
                    </a>
				</div>
				<?php endif; ?>
			
		</div>
		<!-- /.box-header -->
		
		<div class="box-body table-responsive no-padding">
		  <table id="tabla_medicamentos" class="table table-striped table-hover hoverTableww">
			<thead>
				<th>Nombre</th>
				<th>Impacto</th>
				<th>Resultado</th>
				<th>Observaciones</th>
			
			</thead>
			<tbody>
				<?php $__currentLoopData = $medicamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				
					<tr class='clickable-roww' data-href="<?php echo e(route('opciones_persona', ['id' => $item->id_persona])); ?>">
						<td><?php echo e($item->nombre); ?> </td>	
						<td><?php echo e($item->efectos); ?></td>
						<td><?php echo e($item->conclusion); ?></td>
						<td><?php echo e($item->meta); ?></td>
						
					</tr>
				
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>

		</table>
			<?php if(count($medicamentos) == 0): ?>
			<div class="box box-primary col-xs-12">
				<div class='aprobado' style="margin-top:70px; text-align: center">
				<label style='color:#177F6B'>
					... no se encontraron resultados para su busqueda...
				</label>
				</div>
			</div>
			<?php endif; ?>
		</div>
		<!-- /.box-body -->
	  </div>

</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

@parent

<script>

	$(".clickable-row").click(function() {
        window.location = $(this).data("href");
    });

</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>