
<section >



<div class="row" >

<div class="col-md-12">

  <div class="box box-primary box-gris">
    <div class="box-header with-border my-box-header">
        <h3 class="box-title"><strong>Roles Asignados</strong></h3>
    </div><!-- /.box-header -->
   
    <div id="zona_etiquetas_roles" style="background-color:white;" >
    
    <br>
    <?php $__currentLoopData = $usuario->getRoles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rl): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
      <span class="label label-warning" style="margin-left:10px;"><?php echo e($rl); ?> </span> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    
    <br><br>
    </div>

  </div> <!--box -->


  <div class="box box-primary   box-gris" style="margin-bottom: 200px;">
    <div class="box-header with-border my-box-header">
        <h3 class="box-title"><strong>Acceso al sistema</strong></h3>
    </div><!-- /.box-header -->
    <div id="notificacion_E3" ></div>
    <div class="box-body">


                  <div class="box-header with-border my-box-header col-md-12" style="margin-bottom:15px;margin-top: 15px;">
                    <h3 class="box-title">Datos de acceso</h3>
                  </div>
       

                <form   action="<?php echo e(url('editar_acceso')); ?>"  method="post" id="f_editar_acceso"  class="formentrada"  >
                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>"> 
                <input type="hidden" name="id_usuario" value="<?php echo e($usuario->id); ?>"> 

                <div class="col-md-6">
                  <div class="form-group">
                    <label class="col-sm-2" for="name">Nombre de Usuario*</label>
                    <div class="col-sm-10" >
                    <input type="name" class="form-control" id="name" name="name"  value="<?php echo e($usuario->name); ?>"  required >
                    </div>
                  </div><!-- /.form-group -->
                </div><!-- /.col -->

                  <div class="col-md-6">
                  <div class="form-group">
                    <label class="col-sm-2" for="email">Nuevo Password*</label>
                    <div class="col-sm-10" >
                    <input type="password" class="form-control" id="password" name="password"  required >
                    </div>

                    </div><!-- /.form-group -->

                  </div><!-- /.col -->


                    <div class=" col-xs-12 box-gris ">
                                        <button type="submit" class="btn btn-primary">Actualizar Acceso</button>
                    </div>

                   </form>

         </div>

  </div>
  </div>                     
</div>
</section>