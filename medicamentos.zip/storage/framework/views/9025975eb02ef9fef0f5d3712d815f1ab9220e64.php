
<div class="box box-primary col-xs-12">


<div class='aprobado' style="margin-top:70px; text-align: center">
  <span class="label label-success">Paciente actualizado<i class="fa fa-check"></i></span><br/>
<label style='color:#177F6B'>
              <?php  echo $msj; ?> 
</label> 

</div>


<div class="margin" style="margin-top:50px; text-align:center;margin-bottom: 50px;">
             
     

              <div class="btn-group" style="margin-left:50px; " >
                     
                      <a href="<?php echo e(url('listado_personas')); ?>" class="btn btn-info"    value=" "  > Listado Personas </a>
             </div>
       

 </div> 



 </div> 