<!-- Main Header -->
<header class="main-header">
    <!-- Header Navbar -->
    <nav class="navbar navbar-static-top" role="navigation">
        <!-- Sidebar toggle button-->
        
<div class="container">

    <div class="navbar-header">
        <?php if (\Shinobi::isRole('super_admin')): ?>
        <a href="<?php echo e(url('listado_personas')); ?>" class="navbar-brand">
        <?php endif; ?>
        <?php if (\Shinobi::isRole('medico')): ?>
        <a href="<?php echo e(url('listado_personas')); ?>" class="navbar-brand">
        <?php endif; ?>
        <?php if (\Shinobi::isRole('paciente')): ?>
        <a href="<?php echo e(route('opciones_persona', ['id' => Auth::user()->id_persona])); ?>" class="navbar-brand">
        <?php endif; ?>
        <i class="fa fa-wpforms"></i> <b>Sistema Experto</b></a>
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
          <i class="fa fa-bars"></i>
        </button>
      </div>
    <!-- Logo -->

        <?php echo $__env->make('layouts.partials.navbar_top', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Navbar Right Menu -->
        <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">
                <!-- Messages: style can be found in dropdown.less-->
                <li class="dropdown messages-menu">
                    <!-- Menu toggle button -->
                    
                    <ul class="dropdown-menu">
                        
                        <li class="header">Mensajes</li>
                        <li>
                            <!-- inner menu: contains the messages -->
                            <ul class="menu">
                                <li><!-- start message -->
                                    
                                        <div class="pull-left">
                                            <!-- User Image -->
                                            
                                        </div>
                                        <!-- Message title and timestamp -->
                                        <h3 style="background-color:#31a65a; text-align:center; color:white" id="clock"></h3>
                                        
                                        <!-- The message -->
                                        
                                    
                                </li><!-- end message -->
                            </ul><!-- /.menu -->
                        </li>
                        
                    </ul>
                </li>
                <!-- /.messages-menu -->


                <!-- Tasks Menu -->
                
                <?php if(Auth::guest()): ?>
                    
                    <li><a href="<?php echo e(url('/login')); ?>"><?php echo e(trans('adminlte_lang::message.login')); ?></a></li>
                <?php else: ?>
                    <!-- User Account Menu -->
                    <li class="dropdown user user-menu">
                        <!-- Menu Toggle Button -->
                          <a href="<?php echo e(url('/logout')); ?>"
                                   onclick="event.preventDefault();
                                       document.getElementById('logout-form').submit();">
                            <!-- The user image in the navbar-->
                            <img src="<?php echo e(asset('/img/on_off.png')); ?>" class="user-image" alt="User Image"/>
                            <!-- hidden-xs hides the username on small devices so only the image appears. -->
                            
                            <label class="text-black "> Salir</label>
                        </a>
                        <ul class="dropdown-menu">
                            <!-- The user image in the menu -->
                            <li class="user-header">

                                <p>
                                    <?php echo e(Auth::user()->name); ?>

                                    <small><script>
                                        var meses = new Array ("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
                                        var f=new Date();
                                        document.write(f.getDate() + " de " + meses[f.getMonth()] + " de " + f.getFullYear());
                                    </script></small>
                                </p>
                            </li>
                            <!-- Menu Body -->
                            
                            <!-- Menu Footer-->
                            <li class="user-footer">
                                
                                <div class="">

                                   <a href="<?php echo e(url('/logout')); ?>"
                                            onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();"  class="btn btn-primary btn-flat btn-block"  >
                                            <label class="text-black "><i class="fa fa-power-off text-black"></i> Salir</label>
                                        </a>

                                        <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>


                                </div>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>

                <!-- Control Sidebar Toggle Button -->
                
            </ul>
        </div>
    </div>
    </nav>
</header>
