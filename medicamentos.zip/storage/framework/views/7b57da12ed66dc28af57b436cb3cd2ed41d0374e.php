<div class="collapse navbar-collapse pull-left" id="navbar-collapse">
    <ul class="nav navbar-nav">
      
      <?php if (\Shinobi::isRole('super_admin')): ?>
      <li>
        <a href="<?php echo e(route('medicamentos')); ?>">
          <img src="<?php echo e(url('img/pill-icon.png')); ?>" class="img-circle" style="width: 25px; height: 25px;" alt=" "/>
        </a>
      </li>
      <li class="dropdown">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Configuracion <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="<?php echo e(url('listado_usuarios')); ?>"><i class="fa fa-list-alt"></i>Usuarios</a></li>
            <?php if(Auth::user()->persona): ?>
            <li><a href="<?php echo e(route('form_editar_persona', ['id' => Auth::user()->persona->id_persona])); ?>"><i class="fa fa-user"></i> Mi perfil</a></li>
            <?php endif; ?>
          </ul>
      </li>
      <?php endif; ?>
      <?php if (\Shinobi::isRole('medico')): ?>
      <li><a href="<?php echo e(route('form_editar_persona', ['id' => Auth::user()->persona->id_persona])); ?>"><i class="fa fa-user"></i> Mi perfil</a></li>
      <?php endif; ?>
      
      
      
    </ul>
    
  </div>
