<?php $__env->startSection('htmlheader_title'); ?>
	Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main-content'); ?>
<section  id="contenido_principal">
<section  id="content">

    <div class="" >
        <div class="container"> 
            <div class="row">
              <div class="col-sm-10 myform-cont" >
                
                     <div class="myform-top">
                        <div class="myform-top-left">
                           
                          <h3>Agregar Antecedentes del Paciente</h3>
                            <p>Por favor llene los siguientes campos</p>
                        </div>
                        <div class="myform-top-right">
                          <i class="fa fa-user-md"></i>
                        </div>
                    </div>

                  <div class="col-md-12" >
                    <?php if(count($errors) > 0): ?>
                        <br>
                        <div class="alert alert-danger">
                            <strong>UPPS!</strong> Error al Registrar<br>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                    
                    <?php endif; ?>
                   </div>

                    <div id="div_notificacion_sol" class="myform-bottom">
                      
                    <form action="<?php echo e(url('guardar_medicamento')); ?>"  method="post" id="" class="">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                        <div class="col-md-12">
                            <div class="form-group">
                                <label >Nombre del Medicamento</label>
                                <input type="input" name="nombre" class="form-control" value="<?php echo e(old('nombre')); ?>" required/>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="text-black">Impacto</label>
                                <div class="form-group bg-gray">
                                    <select  class="form-control" name="impacto" required>
                                      <?php if(!old('impacto')): ?>
                                        <option value="" selected> --- ELIJA UNA OPCION --- </option>
                                        <?php $__currentLoopData = $impactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impacto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value=<?php echo e($impacto); ?>><?php echo e($impacto); ?></option>                                                
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                      <?php else: ?>
                                        <option value=""> --- ELIJA UNA OPCION --- </option>
                                        <?php $__currentLoopData = $impactos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $impacto): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($impacto); ?>" <?php echo e(old('impacto', $impacto) == $impacto ? 'selected' : ''); ?>><?php echo e($impacto); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                      <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label >Resultado</label>
                                <input type="input" name="conclusion" class="form-control" value="<?php echo e(old('conclusion')); ?>" required/>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <label >Observaciones</label>
                                <textarea class="form-control" name="meta" rows="3" value="<?php echo e(old('meta')); ?>" required></textarea>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <br>
                        </div>
                        <button type="submit" class="mybtn">Guardar</button>
                      </form>
                    
                    </div>
              </div>
            </div>

        </div>
      </div>
 
</section>

</section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>