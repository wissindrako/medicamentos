<!-- Main Footer -->
<footer class="main-footer">
    <strong>Copyright &copy; 2020 <a href="#"> UNIVERSIDAD PRIVADA DEL VALLE</a>
    </strong> - FACULTAD DE INFORMÁTICA Y ELECTRÓNICA - CARRERA DE INGENIERÍA DE SISTEMAS INFORMÁTICOS.
</footer>