<!DOCTYPE html>
<html>

 <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Sistema Experto</title>

    <!-- CSS de Bootstrap -->
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('css/mycustom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('font-awesome/css/font-awesome.min.css')); ?>"> <!--Iconos-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,300,400,500" >

  </head>


<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(url('js/bootstrap.min.js')); ?>"></script>
</html>
